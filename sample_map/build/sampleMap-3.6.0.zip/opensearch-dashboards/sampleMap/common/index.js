"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.VM_PROXY_BASE = exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = exports.PLUGIN_ID = 'sampleMap';
/** Nav/app title of the map. */
const PLUGIN_NAME = exports.PLUGIN_NAME = 'Gensco';

/** Server route prefix for the VictoriaMetrics proxy. */
const VM_PROXY_BASE = exports.VM_PROXY_BASE = '/api/sample_map/vm';
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJleHBvcnRzIiwiUExVR0lOX05BTUUiLCJWTV9QUk9YWV9CQVNFIl0sInNvdXJjZXMiOlsiaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IFBMVUdJTl9JRCA9ICdzYW1wbGVNYXAnO1xyXG4vKiogTmF2L2FwcCB0aXRsZSBvZiB0aGUgbWFwLiAqL1xyXG5leHBvcnQgY29uc3QgUExVR0lOX05BTUUgPSAnR2Vuc2NvJztcclxuXHJcbi8qKiBTZXJ2ZXIgcm91dGUgcHJlZml4IGZvciB0aGUgVmljdG9yaWFNZXRyaWNzIHByb3h5LiAqL1xyXG5leHBvcnQgY29uc3QgVk1fUFJPWFlfQkFTRSA9ICcvYXBpL3NhbXBsZV9tYXAvdm0nO1xyXG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFPLE1BQU1BLFNBQVMsR0FBQUMsT0FBQSxDQUFBRCxTQUFBLEdBQUcsV0FBVztBQUNwQztBQUNPLE1BQU1FLFdBQVcsR0FBQUQsT0FBQSxDQUFBQyxXQUFBLEdBQUcsUUFBUTs7QUFFbkM7QUFDTyxNQUFNQyxhQUFhLEdBQUFGLE9BQUEsQ0FBQUUsYUFBQSxHQUFHLG9CQUFvQiJ9